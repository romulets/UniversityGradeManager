﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UniversityGradeManager.Views.Graduation
{
    public partial class list : System.Web.UI.Page
    {

        [Bindable(true)]
        public Entities.Graduation Graduation { get; set; }

        protected void Page_Init(object sender, EventArgs e)
        {
            Graduation = new Entities.Graduation
            {
                Id = 1,
                Name = "Bacharelado em Sistemas de Informação",
            };

            Entities.Period period1 = new Entities.Period { Id = 1 };
            period1.Discplines.Add(new Entities.Discipline
            {
                Name = "Laboratório de Informática I",
                TheorycClassesCount = 0,
                PractiseClassesCount = 2,
                NumberOfCredits = 1,
                Workload = 36,
                ClockHours = 36
            });
            period1.Discplines.Add(new Entities.Discipline
            {
                Name = "Programação I",
                TheorycClassesCount = 2,
                PractiseClassesCount = 4,
                NumberOfCredits = 4,
                Workload = 108,
                ClockHours = 108
            });

            Entities.Period period2 = new Entities.Period { Id = 2 };
            period2.Discplines.Add(new Entities.Discipline
            {
                Name = "Laboratório de Informática II",
                TheorycClassesCount = 0,
                PractiseClassesCount = 2,
                NumberOfCredits = 1,
                Workload = 36,
                ClockHours = 36
            });

            period2.Discplines.Add(new Entities.Discipline
            {
                Name = "Programação II",
                TheorycClassesCount = 2,
                PractiseClassesCount = 4,
                NumberOfCredits = 4,
                Workload = 108,
                ClockHours = 108
            });

            Graduation.Periods.Add(period1);
            Graduation.Periods.Add(period2);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                ctrlGraduation.DataBind();
        }
    }
}